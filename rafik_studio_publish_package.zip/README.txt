Rafik Studio — Free Website Publish Package

Files:
- index.html: website prototype entry page

How to publish free using GitHub Pages from Android:
1. Sign in at https://github.com/
2. Create a new public repository named rafik-studio
3. Upload index.html to the repository root (not inside another folder).
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for the published URL shown in Settings -> Pages.

Important:
This is a frontend demo only. It does not generate real AI videos yet.
Do not upload API keys or passwords into index.html or a public repository.
